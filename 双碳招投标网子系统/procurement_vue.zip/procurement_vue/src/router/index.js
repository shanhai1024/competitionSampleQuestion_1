import Vue from "vue";
import Router from "vue-router";

Vue.use(Router);

import Procurement from "@/views/procurement";
import User from "@/views/procurement/user";
import UserInformation from "@/views/procurement/user/userInformation";


/* Router Modules */
export const constantRoutes = [
  {
    path: "/login",
    component: () => import("@/views/login/index"),
    hidden: true,
  },
  {
    path: "/",
    component: () => import("@/layout/procurement"),
    name: "procurement",
    redirect: "index",
    children: [
      // 首页
      {
        path: "/index",
        name: "index",
        component: Procurement,
      },
      // 用户中心
      {
        path: "/user",
        name: "user",
        component: User,
        children: [
          // 用户中心
          {
            path: "/userInformation",
            name: "userInformation",
            component: UserInformation,
          },
        ]
      }
    ],
  },
  {
    path: "/applylicense",
    component: (resolve) => require(["@/views/applylicense"], resolve),
    hidden: true,
  },
];

/**
 * asyncRoutes
 * the routes that need to be dynamically loaded based on user roles
 */
export const asyncRoutes = [{ path: "*", redirect: "/404", hidden: true }];

const createRouter = () =>
  new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRoutes,
  });

const router = createRouter();

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter();
  router.matcher = newRouter.matcher; // reset router
}

export default router;
