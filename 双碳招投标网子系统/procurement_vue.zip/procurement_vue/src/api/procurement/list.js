import request from '@/utils/request'

// 获取(平台动态,信息公告,政策法规)列表

// 获取(平台动态,信息公告,政策法规)详情

