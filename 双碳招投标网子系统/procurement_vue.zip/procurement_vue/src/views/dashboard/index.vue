<template>
  <div class="dashboard-container">
    index
  </div>
</template>

<script>

export default {
  name: 'Dashboard',
  data() {
    return {}
  }

}
</script>
