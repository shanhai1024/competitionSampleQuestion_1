<template>
  <div class="home1 center">
    <div class="user_l">
      <div>用户中心</div>
      <div>企业信息</div>
      <div>我的投标</div>
      <div>参与投标</div>
    </div>
    <div class="user_r">
      <router-view/>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      type: ""
    };
  },
  mounted() {},
  computed: {},
  methods: {}
};
</script>
<style scoped>
.home1 {
  display: flex;
  padding-top: 50px;
}
.user_l {
  width: 12%;
  border: 1px solid #e5e5e5;
  border-radius: 5px;
  margin-right: 20px;
  padding: 20px;
  margin-bottom: 50px;
}
.user_l > div {
  height: 40px;
  line-height: 40px;
  text-align: center;
}
.user_l > div:hover {
  cursor: pointer;
  color: #409EFF;
}
.user_r {
  min-height: 500px;
  width: 82%;
  border: 1px solid #e5e5e5;
  padding: 20px;
  margin-bottom: 50px;
}
</style>
