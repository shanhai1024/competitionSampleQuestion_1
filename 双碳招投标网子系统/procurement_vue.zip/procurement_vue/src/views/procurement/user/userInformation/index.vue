<template>
  <div class="home">
    <div>
      <span>用户名称：</span>
      <span>{{ userRes.userName }}</span>
    </div>
    <div>
      <span>ip属地：</span> <span>{{ userRes.loginIp }}</span>
    </div>
    <div>
      <span>所属机构：</span> <span>{{ userRes.userName }}</span>
    </div>
    <div>
      <span>手机号码：</span> <span>{{ userRes.phonenumber }}</span>
    </div>
    <div>
      <span>邮箱：</span> <span>{{ userRes.email }}</span>
    </div>
    <div><span>当前密码：</span> <span>* * * * * *</span></div>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
export default {
  data() {
    return {
      userRes: {},
    };
  },
  mounted() {
    this.userRes = this.$store.state.user.userRes;
  },
  computed: {},
  methods: {},
};
</script>
<style scoped>
.home > div {
  margin: 25px 40px;
  font-size: 18px;
}
.home > div > span:nth-child(2) {
  color: #666;
}
</style>
