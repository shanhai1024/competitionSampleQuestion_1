<template>
  <div class="home">
    <div class="center">
      <el-row
        class="head"
        :gutter="10"
        type="flex"
        align="middle"
        justify="space-between"
      >
        <el-col :span="3">
          <div class="pointer title" @click="$router.push('/')">
            <img style="width: 160px;margin-top: 10px" src="../../../assets/images/logo.png" alt>
          </div>
        </el-col>
        <el-col :span="16">
          <el-row>
            <el-col :span="3" class="pointer">
              <div class="pointer">
                平台动态
              </div>
            </el-col>
            <el-col :span="3" class="pointer">
              <div class="pointer">
                信息公告
              </div>
            </el-col>
            <el-col :span="3" class="pointer">
              <div class="pointer">
                政策法规
              </div>
            </el-col>
            <el-col :span="3" class="pointer">
              <div class="pointer">
                违规投诉
              </div>
            </el-col>
          </el-row>
        </el-col>
        <el-col :span="3">
          <div>
            <div class="pointer" @click="$router.push('/userInformation')">
              <el-avatar :size="45" :src="avatar">
                <img
                  src="../../../assets/images/avatar.png"
                />
              </el-avatar>
            </div>
            <div>
              <el-dropdown
                trigger="click"
                class="pointer"
                @command="elDropdown"
              >
                <span class="el-dropdown-link" style="color: #fff;">
                  {{ name }}
                  <i class="el-icon-arrow-down el-icon--right"></i>
                </span>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item command="userInformation"
                    >用户中心</el-dropdown-item
                  >
                  <el-dropdown-item command="bidList"
                    >参与投标</el-dropdown-item
                  >
                  <el-dropdown-item command="enterpriseInformation"
                    >企业信息</el-dropdown-item
                  >
                  <el-dropdown-item command="TargetList"
                    >我的投标</el-dropdown-item
                  >
                  <el-dropdown-item command="login">退出登入</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
import { logout } from "@/api/login";
import jsCookie from "js-cookie";
import { mapGetters } from "vuex";
export default {
  data() {
    return {};
  },
  computed: {
    ...mapGetters(["name", "avatar"]),
  },
  mounted() {
    console.log(this.name);
  },
  methods: {
    elDropdown(name) {
      if (name == "login") {
        logout().then((res) => {
          console.log(res);
          this.$store.dispatch("user/logout");
          this.$store.dispatch("user/resetToken");
          this.$router.push("/login");
        });
      } else {
        this.$router.push("/" + name);
      }
    },
  },
};
</script>
<style scoped>
.home {
  height: 100px;
  background: url("../../../assets/images/login-bg1.png");
  /* background:repeating-linear-gradient(to right,#a2dbb7, #259440); */
  background-repeat: no-repeat;
  background-position: 100% 20%;
  background-size: 100%;
  width: 100%;
  height: 100px;
}
.head {
  height: 85px;
}
.title {
  height: 100%;
  font-size: 28px;
  display: flex;
  justify-content: center;
}
.el-dropdown {
  color: #000 !important;
}

.pointer {
  flex: 1;
  display: flex;
  height: 100%;
}
.pointer > div {
  font-size: 18px;
  font-weight: 600;
  width: 100px;
  display: inline-block;
  text-align: center;
  line-height: 90px;
  color: #fff;
}
.pointer > div:hover {
  cursor: pointer;
  color: #1a6ff8;
  /*color: rgb(26,133,199)*/
}
</style>
