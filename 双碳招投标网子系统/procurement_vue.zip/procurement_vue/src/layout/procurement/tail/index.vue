<template>
  <div class="home">
    <!-- 底部 -->
    <div class="bottom">
      <div class="item">
        <h3>加入我们</h3>
        <div>社会招聘</div>
        <div>校园招聘</div>
        <div>国际招聘</div>
      </div>
      <div class="item">
        <h3>商务洽谈</h3>
        <div>客户服务</div>
        <div>合作洽谈</div>
        <div>媒体及投资者</div>
      </div>
      <div class="item">
        <h3>法律信息</h3>
        <div>服务协议</div>
        <div>隐私政策</div>
        <div>知识产权</div>
      </div>
      <div class="item">
        <h3>关于我们</h3>
        <div>公司介绍</div>
        <div>意见反馈</div>
        <div>关于我们</div>
      </div>
      <div class="item">
        <h2 style="margin: 30px 0;">联系我们</h2>
        <h3>+(86)13411111111</h3>
        <div>
          <img src="../../../assets/images/icon_wechat.png" alt>
          <img src="../../../assets/images/icon_weibo.png" alt>
          <img src="../../../assets/images/icon_twitter.png" alt>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  mounted() {},
  computed: {},
  methods: {}
};
</script>
<style scoped>
.bottom {
  width: 1200px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 230px;
}
.home {
  background-color: rgb(162,219,183);
}
.item {
  text-align: center;
}
.item > div {
  margin: 3px 0;
}
.item img {
  width: 40px;
  height: 40px;
  margin: 0 5px;
}
</style>
