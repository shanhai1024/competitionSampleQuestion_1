<template>
  <div class="home">
    <Head></Head>
    <router-view />
    <Tail></Tail>
  </div>
</template>
<script>
import Head from "@/layout/procurement/head";
import Tail from "@/layout/procurement/tail";
export default {
  data() {
    return {};
  },
  components: {
    Head,
    Tail,
  },
  mounted() {},
  computed: {},
  methods: {},
};
</script>
<style scoped>
</style>
