<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: "App",
};
</script>
<style>
/* #app {
  height: 100px;
  background: url("./assets/images/bg1.png");
  background-repeat: no-repeat;
  background-position: 100% 20%;
  background-size: 100%;
  width: 100%;
  height: 100px;
} */

.pointer {
  cursor: pointer;
}
.center {
  width: 1200px;
  margin: 0 auto;
}
.BeyondHiding {
  overflow: hidden;
  text-overflow: ellipsis;
  flex-wrap: nowrap;
}
</style>