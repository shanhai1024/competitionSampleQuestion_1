<template>

</template>
<script>

export default {
  name: "energyByhour",
  components: {
  },
  data() {
    return {

    };
  },
  created() {
    this.getList();
  },
  methods: {

  }
};
</script>
