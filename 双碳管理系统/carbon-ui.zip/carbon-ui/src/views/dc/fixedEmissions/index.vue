<template>
</template>

<script>

export default {
  name: "FixedEmissions",
  data() {
    return {

    };
  },
  created() {
  },
  methods: {

  }
};
</script>
