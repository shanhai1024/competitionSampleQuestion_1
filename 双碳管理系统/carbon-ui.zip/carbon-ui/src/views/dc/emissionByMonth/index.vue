<template>

</template>

<script>

export default {
  name: "emissionByMonth",
  components: {
  },
  data() {
    return {

    };
  },
  created() {
  },
  methods: {

  }
};
</script>
