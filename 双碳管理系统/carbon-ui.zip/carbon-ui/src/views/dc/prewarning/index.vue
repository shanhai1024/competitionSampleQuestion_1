<template>

</template>

<script>

export default {
  name: "Prewarning",
  data() {
    return {

    };
  },
  created() {
  },
  methods: {

  }
};
</script>
