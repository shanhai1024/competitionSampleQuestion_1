<template>

</template>

<script>

export default {
  name: "emissionByYear",
  components: {
  },
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
