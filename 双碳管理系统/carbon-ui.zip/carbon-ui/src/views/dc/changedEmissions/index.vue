<template>

</template>

<script>

export default {
  name: "ChangedEmissions",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
