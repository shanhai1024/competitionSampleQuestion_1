<template>

</template>

<script>

export default {
  name: "energyAnalysis",
  components: {
  },
  data() {
    return {

    };
  },
  created() {
  },
  methods: {

  }
};
</script>
