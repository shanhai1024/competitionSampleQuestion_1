<template>

</template>

<script>
export default {
  name: "Proportion",
  components: {},
  data() {
    return {

    };
  },
  created() {
  },
  methods: {

  }
};

</script>
