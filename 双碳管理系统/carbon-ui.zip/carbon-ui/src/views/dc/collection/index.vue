<template>

</template>

<script>

export default {
  name: "Collection",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
