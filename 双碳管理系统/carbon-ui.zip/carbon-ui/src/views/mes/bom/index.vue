<template>

</template>

<script>
export default {
  name: "Bom",
  data() {
    return {


    };
  },
  created() {

  },

  methods: {

  }
};
</script>
