<template>

</template>

<script>
export default {
  name: "Factory",
  data() {
    return {

    };
  },
  created() {

  },

  methods: {

  }
};
</script>
