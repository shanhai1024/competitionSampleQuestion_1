<template>

</template>

<script>
export default {
  name: "Sampling",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
