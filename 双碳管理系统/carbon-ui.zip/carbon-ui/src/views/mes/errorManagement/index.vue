<template>

</template>

<script>

export default {
  name: "ErrorManagement",
  data() {
    return {

    };
  },
  created() {
  },
  methods: {

  }
};
</script>
