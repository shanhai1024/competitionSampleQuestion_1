<template>

</template>

<script>
export default {
  name: "Plan",
  data() {
    return {

    };
  },
  created() {

  },

  methods: {

  }
};
</script>
