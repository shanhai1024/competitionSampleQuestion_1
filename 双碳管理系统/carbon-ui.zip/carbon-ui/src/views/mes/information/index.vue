<template>

</template>

<script>

export default {
  name: "Information",
  data() {
    return {

    };
  },
  created() {
  },
  methods: {

  }
};
</script>
