<template>

</template>

<script>
export default {
  name: "Inspector",
  data() {
    return {

    };

  },
  created() {

  },
  methods: {

  },
};
</script>
