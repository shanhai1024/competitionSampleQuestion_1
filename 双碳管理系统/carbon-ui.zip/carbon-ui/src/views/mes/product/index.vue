<template>

</template>

<script>
export default {
  name: "Product",
  data() {
    return {

    };
  },
  created() {

  },

  methods: {

  }
};
</script>
