<template>

</template>

<script>
export default {
  name: "traceability",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  },
};
</script>
