<template>

</template>

<script>
export default {
  name: "Apply",
  data() {
    return {

    }
  },
  created() {

  },
  methods: {

  }
};
</script>
