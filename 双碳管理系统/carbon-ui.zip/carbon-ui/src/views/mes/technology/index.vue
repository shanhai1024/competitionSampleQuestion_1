<template>

</template>

<script>
export default {
  name: "Technology",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
