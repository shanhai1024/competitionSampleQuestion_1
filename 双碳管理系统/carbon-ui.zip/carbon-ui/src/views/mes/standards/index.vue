<template>

</template>

<script>
export default {
  name: "Standards",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  },
};
</script>
