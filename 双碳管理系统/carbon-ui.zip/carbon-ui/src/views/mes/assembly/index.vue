<template>

</template>

<script>
export default {
  name: "Assembly",
  data() {
    return {

    };
  },

  created() {
  },
  methods: {

  }
};
</script>
