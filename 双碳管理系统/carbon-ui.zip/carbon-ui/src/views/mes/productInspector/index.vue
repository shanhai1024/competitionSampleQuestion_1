<template>

</template>

<script>
export default {
  name: "ProductInspector",
  data() {
    return {

    };
  },
  created() {
  },
  methods: {

  },
};
</script>
