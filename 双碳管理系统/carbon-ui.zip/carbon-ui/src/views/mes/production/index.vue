<template>

</template>

<script>
export default {
  name: "Production",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
