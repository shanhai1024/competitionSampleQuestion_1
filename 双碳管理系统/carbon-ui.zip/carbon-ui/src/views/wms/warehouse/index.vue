<template>

</template>

<script>
export default {
  name: "Warehouse",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
