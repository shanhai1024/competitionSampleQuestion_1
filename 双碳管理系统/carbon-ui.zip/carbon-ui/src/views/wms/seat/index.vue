<template>

</template>

<script>
export default {
  name: "Seat",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
