<template>

</template>

<script>
export default {
  name: "CarierApplication",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
