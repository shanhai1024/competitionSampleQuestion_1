<template>

</template>

<script>
export default {
  name: "Inventory",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
