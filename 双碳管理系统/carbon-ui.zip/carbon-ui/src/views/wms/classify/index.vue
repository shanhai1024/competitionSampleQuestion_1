<template>

</template>

<script>
export default {
  name: "Classify",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
