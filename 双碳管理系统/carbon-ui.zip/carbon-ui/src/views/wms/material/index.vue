<template>

</template>

<script>
export default {
  name: "Material",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
