<template>

</template>

<script>
export default {
  name: "VehicleScheduling",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
