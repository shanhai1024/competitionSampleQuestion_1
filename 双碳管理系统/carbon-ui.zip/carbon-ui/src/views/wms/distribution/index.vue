<template>

</template>

<script>
export default {
  name: "Distribution",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
