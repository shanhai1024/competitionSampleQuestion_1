<template>

</template>

<script>
export default {
  name: "Area",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
