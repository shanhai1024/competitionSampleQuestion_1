<template>

</template>

<script>
export default {
  name: "InventoryDetails",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
