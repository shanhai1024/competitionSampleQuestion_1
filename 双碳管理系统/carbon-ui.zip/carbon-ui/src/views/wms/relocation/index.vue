<template>

</template>

<script>
export default {
  name: "Relocation",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
