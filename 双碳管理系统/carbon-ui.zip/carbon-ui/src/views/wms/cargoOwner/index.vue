<template>

</template>

<script>
export default {
  name: "CargoOwner",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
