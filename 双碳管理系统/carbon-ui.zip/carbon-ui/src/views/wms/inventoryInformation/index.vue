<template>

</template>

<script>
export default {
  name: "InventoryInformation",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
