<template>

</template>

<script>
export default {
  name: "PurchaseReturn",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
