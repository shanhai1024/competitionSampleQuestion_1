<template>

</template>

<script>
export default {
  name: "Delivery",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
