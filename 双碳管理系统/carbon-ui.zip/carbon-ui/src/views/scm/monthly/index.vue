<template>

</template>

<script>
export default {
  name: "Monthly",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
