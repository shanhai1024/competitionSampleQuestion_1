<template>

</template>

<script>
export default {
  name: "Order",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
