<template>

</template>

<script>
export default {
  name: "PurchaseReceipt",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
