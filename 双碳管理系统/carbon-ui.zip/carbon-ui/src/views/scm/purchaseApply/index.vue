<template>

</template>

<script>
export default {
  name: "PurchaseApply",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
