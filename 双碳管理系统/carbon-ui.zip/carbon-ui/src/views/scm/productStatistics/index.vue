<template>

</template>

<script>
export default {
  name: "ProductStatistics",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
