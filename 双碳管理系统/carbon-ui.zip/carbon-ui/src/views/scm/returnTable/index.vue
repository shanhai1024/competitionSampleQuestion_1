<template>

</template>

<script>
export default {
  name: "ReturnTable",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
