<template>

</template>

<script>
export default {
  name: "Supplier",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
