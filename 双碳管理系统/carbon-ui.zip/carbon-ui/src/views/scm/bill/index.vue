<template>

</template>

<script>
export default {
  name: "Bill",
  data() {
    return {

    };
  },
  created() {
  },
  methods: {

  }
};
</script>
