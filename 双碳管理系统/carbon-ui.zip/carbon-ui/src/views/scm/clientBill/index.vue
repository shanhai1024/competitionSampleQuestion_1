<template>

</template>

<script>
export default {
  name: "ClientBill",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
