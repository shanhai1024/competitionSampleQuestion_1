<template>

</template>

<script>
export default {
  name: "Custom",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
