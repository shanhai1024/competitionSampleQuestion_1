<template>

</template>

<script>
export default {
  name: "PurchasePlan",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
