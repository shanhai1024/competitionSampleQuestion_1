<template>

</template>

<script>
export default {
  name: "PurchaseArrival",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
