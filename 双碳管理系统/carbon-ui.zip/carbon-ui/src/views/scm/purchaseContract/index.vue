<template>

</template>

<script>
export default {
  name: "PurchaseContract",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
