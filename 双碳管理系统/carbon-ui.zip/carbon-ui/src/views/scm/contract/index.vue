<template>

</template>

<script>
export default {
  name: "Contract",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
