<template>

</template>

<script>
export default {
  name: "SupplierBill",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
