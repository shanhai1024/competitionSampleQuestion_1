<template>

</template>
<script>
export default {
  name: "index",
  components: {},
  data() {
    return {

    }
  },
  created(){
  },
  methods:{

  }
}
</script>

</style>
