<template>

</template>

<script>
export default {
  name: "ProcurementPlan",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
