<template>

</template>

<script>
export default {
  name: "saleOrder",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
