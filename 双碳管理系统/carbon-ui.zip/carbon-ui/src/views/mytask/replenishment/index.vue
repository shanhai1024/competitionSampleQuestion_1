<template>

</template>

<script>
export default {
  name: "ReplenishmentApplication",
  data() {
    return {

    };
  },
  created() {
  },
  methods: {

  }
};
</script>
