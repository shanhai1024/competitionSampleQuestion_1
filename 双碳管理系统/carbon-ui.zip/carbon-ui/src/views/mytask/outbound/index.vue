<template>

</template>

<script>
export default {
  name: "OutboundApplication",
  data() {
    return {}
  },

  created() {
  },
  methods: {

  }
};
</script>
