<template>

</template>

<script>
export default {
  name: "WarehousingApplication",
  data() {
    return {

    };
  },
  created() {
  },

  methods: {

  }
};
</script>
