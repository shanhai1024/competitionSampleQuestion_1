<template>

</template>

<script>
export default {
  name: "CarrierApplication",
  data() {
    return {

    };
  },
  created() {

  },
  methods: {

  }
};
</script>
