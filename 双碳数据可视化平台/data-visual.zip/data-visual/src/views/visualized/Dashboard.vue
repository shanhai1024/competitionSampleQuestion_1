<template>


</template>

<script>

export default {
  name: "Dashboard",
  mounted(){
  },
  data() {
    return  {

    }
  },
  methods:{
  }
}
</script>

<style scoped>

</style>
