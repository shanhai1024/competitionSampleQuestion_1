<template>


</template>

<script>
export default {
  name: "Ringlike",
  mounted(){

  },
  data() {
    return  {

    }
  },
  methods:{

  }
}
</script>

<style scoped>

</style>
