<template>

</template>

<script>
export default {
  name: "SalePlan",
  mounted(){

  },
  methods:{

  }
}
</script>

<style scoped>

</style>
