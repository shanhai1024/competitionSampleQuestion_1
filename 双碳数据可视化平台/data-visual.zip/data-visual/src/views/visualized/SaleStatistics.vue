<template>

</template>

<script>
export default {
  name: "SaleStatistics",
  data() {
    return  {

    }
  },
  mounted(){

  },
  methods:{


  }
}
</script>

<style scoped>

</style>
