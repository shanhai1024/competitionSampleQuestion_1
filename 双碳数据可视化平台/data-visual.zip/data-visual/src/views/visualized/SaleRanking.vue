<template>

</template>

<script>
export default {
  name: "SaleRanking",
  data() {
    return {

    }
  },
  mounted() {

  },
  methods: {

  }
}
</script>

<style scoped>

</style>
