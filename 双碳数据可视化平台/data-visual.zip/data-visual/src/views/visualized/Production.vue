<template>

</template>

<script>

export default {
  name: "Inventory",
  data(){
    return{
    }
  },
  created() {
  },
  methods:{


  },
  mounted() {

  },
  beforeDestroy(){

  }
}
</script>

<style lang="scss" scoped>

</style>
