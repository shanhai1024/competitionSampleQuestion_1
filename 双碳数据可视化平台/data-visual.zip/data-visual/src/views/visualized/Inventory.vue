<template>

</template>

<script>

export default {
  name: "Inventory",
  data() {
    return {
    }
  },
  created() {
    this.getList()
  },
  methods: {
  },
  mounted() {

  },
}
</script>

<style lang="scss" scoped>

</style>
