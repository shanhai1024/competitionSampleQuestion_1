<template>


</template>
<script>

export default {
  name: "index",
  components: {},
  data() {
    return {

    }
  },
  mounted() {

  },
  methods: {

  },
  beforeDestroy() {

  }
}
</script>
<style lang="scss" scoped>

</style>
