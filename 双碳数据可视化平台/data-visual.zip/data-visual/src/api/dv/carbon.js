import request from '@/utils/request'


// 查询生产能耗日报表
export function productPowerReportByDay(query) {
  return request({
    url: '/carbonReport/productPowerDetails/day',
    method: 'get',
    params: query
  })
}

// 查询生产能耗月度报表
export function productPowerReportByMonth(query) {
  return request({
    url: '/carbonReport/productPowerDetails/month',
    method: 'get',
    params: query
  })
}

// 查询生产能耗年度列表
export function productPowerReportByYear(query) {
  return request({
    url: '/carbonReport/productPowerDetails/year',
    method: 'get',
    params: query
  })
}

// 查询设备能耗列表
export function listDevicePowerReport(query) {
  return request({
    url: '/carbonReport/devicePowerDetails/list',
    method: 'get',
    params: query
  })
}



// 查询产品能耗
export function productPowerReportOverall(query) {
  return request({
    url: '/carbonReport/productPowerDetails/list',
    method: 'get',
    params: query
  })
}


// 查询今年的能耗占比
export function getEmissionPercent(query) {
  return request({
    url: '/carbonReport/emissionChart/percent',
    method: 'get',
    params: query
  })
}

// 销售统计
export function getSaleStat(query) {
  return request({
    url: '/carbonReport/saleStat',
    method: 'get',
    params: query
  })
}

// 销售排行
export function getSaleCustomer(query) {
  return request({
    url: '/carbonReport/saleCustomer/ranking',
    method: 'get',
    params: query
  })
}

// 销售排行
export function getSaleAchieveRate(query) {
  return request({
    url: '/carbonReport/salePlan/achieveRate',
    method: 'get',
    params: query
  })
}

// 销售总览
export function getSaleOverall(query) {
  return request({
    url: '/carbonReport/saleOverall',
    method: 'get',
    params: query
  })
}

// 查询物料库存列表
export function listInventory(query) {
  return request({
    url: '/wms/inventory/list',
    method: 'get',
    params: query
  })
}



